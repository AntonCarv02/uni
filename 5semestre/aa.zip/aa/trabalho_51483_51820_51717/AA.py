import numpy as np
import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import MultinomialNB
from sklearn.preprocessing import LabelEncoder
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.utils.validation import check_X_y, check_array, check_is_fitted
from sklearn.model_selection import train_test_split

class KNeigborsClassUE:
    def __init__(self, k=3, p=2.0):
        self.k = k
        self.p = p
        self.X_train = None
        self.y_train = None

    def fit(self, X, y):
        self.X_train = X
        self.y_train = y

    def predict(self, X):
        predictions = []
        for sample in X:
            distances = np.linalg.norm(self.X_train - sample, ord=self.p, axis=1)
            sorted_indices = np.argsort(distances)
            k_nearest_labels = self.y_train[sorted_indices[:self.k]]
            unique_labels, counts = np.unique(k_nearest_labels, return_counts=True)
            predicted_label = unique_labels[np.argmax(counts)]
            predictions.append(predicted_label)
        return np.array(predictions)
    

    def score(self, X, y):
        predictions = self.predict(X)
        accuracy = np.mean(predictions == y)
        return accuracy

class NBayesClassUE(BaseEstimator, ClassifierMixin):
    def __init__(self, alpha=1.0):
        self.alpha = alpha
        self.model = MultinomialNB(alpha=alpha)

    def fit(self, X, y):
        
        # Verifica se X e y têm o mesmo número de amostras
        X, y = check_X_y(X, y, accept_sparse=True)

        #Codifica os dados nominais
        label_encoder = LabelEncoder()
        X_encoded = X.apply(label_encoder.fit_transform)

        #Treina o modelo
        self.model.fit(X_encoded, y)

    def predict(self, X):
        # Verifica se o modelo foi treinado
        check_is_fitted(self.model)

        # Verifica se X é uma matriz válida
        X = check_array(X, accept_sparse=True)

        # Codifica os dados nominais
        label_encoder = LabelEncoder()
        X_encoded = X.apply(label_encoder.fit_transform)

        # Faz previsões
        return self.model.predict(X_encoded)

    def score(self, X, y):
        # Verifica se X e y têm o mesmo número de amostras
        X, y = check_X_y(X, y, accept_sparse=True)

        # Codifica os dados nominais
        label_encoder = LabelEncoder()
        X_encoded = X.apply(label_encoder.fit_transform)

        # Retorna a acurácia
        return self.model.score(X_encoded, y)




dataFrame = pd.read_csv(filepath_or_buffer='trabalho_51483_51820_51717/numericos/rice.csv')

# Seleciona todas as linhas e todas as colunas exceto a última do DataFrame
X = dataFrame.iloc[:, :-1].values  # Atributos
y = dataFrame.iloc[:, -1].values  # Rótulos

# Divide os dados em conjuntos de treino e teste
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, train_size=0.75, random_state=3)

# Inicializa e treina o modelo
k_to_test = {1,3,4,9}
p_to_test = {1,2}

for p_value in p_to_test:
  for k_value in k_to_test:

    # incializa os testes de forma dinamica
    KNN_UE = KNeigborsClassUE(k=k_value, p=p_value)
    KNN_UE.fit(X_train, y_train)

    # Faz previsões e calcula a precisão
    accuracy = KNN_UE.score(X_test, y_test)
    # print(f"K = {k_value} & p = {p_value} : Accuracy = {accuracy}")

    # -------------

    # Verificar se os valores estao bem calculados com o scikit-learn
    knn_sklearn = KNeighborsClassifier(n_neighbors=k_value, p=p_value)
    knn_sklearn.fit(X_train, y_train)

    predictions_sklearn = knn_sklearn.predict(X_test)

    accuracy_sklearn = accuracy_score(y_test, predictions_sklearn)

    # print(f"Accuracy com o scikit-learn (K = {k_value} & p = {p_value} : Accuracy = {accuracy_sklearn})")

    print(f"K: {k_value} | p: {p_value} :\nKNN_UE: {accuracy} | Sklearn: {accuracy_sklearn}\n")